package com.mycompany.dbuilt;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBuilt {

	public static Connection con;
	public static Connection getConnection(){
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/productdb","root","1234567890");
			
			return con;
		
		} catch (ClassNotFoundException ex) {
			
			ex.printStackTrace();
		}catch (SQLException e) {
			// TODO: handle exception
		}
		return null;
	}
}
