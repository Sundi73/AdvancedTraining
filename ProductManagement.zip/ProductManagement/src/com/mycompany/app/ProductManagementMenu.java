package com.mycompany.app;

import java.util.List;
import java.util.Scanner;
import com.mycompany.dao.*;
import com.mycompany.domain.*;

public class ProductManagementMenu {
	
	public static void welcomeScreen() {
		System.out.println("---Product Management App---");
		System.out.println("A. View Product");
		System.out.println("B. Add Product");
		System.out.println("C. Update Product");
		System.out.println("D. Delete Product");
		System.out.println("E. Search Product");
		System.out.println("F. Exit");
		
		System.out.println("=====================");
		System.out.println("Enter an option");
		System.out.println("=====================");
	}
	
	public static void handleApp() {
		boolean showDetail = true;
		welcomeScreen();
		Scanner scan = new Scanner(System.in);
		
		do {
			try {
				String option = scan.nextLine();
			
				switch (option.charAt(0)) {
				case 'A': {
					showAllProduct();
					handleApp();
					break;
					}
				case 'B' : {
					insertValueInDatabase();
					handleApp();
					break;
				}
				case 'C':{
					
					UpdateProductInDatabase();
					handleApp();
					break;
				}
				case 'D' :{
					System.out.println("----------------------\n"+"Enter Product ID :\n----------------------");
					deleteValueFromDatabase(Integer.parseInt(scan.nextLine()));
					handleApp();
					break;
				}
				case 'E':{
					System.out.println("----------------------\n"+"Enter Product ID :\n----------------------");
					searchProduct(Integer.parseInt(scan.nextLine()));
					handleApp();
					
					break;
				}
				case 'F' :{
					System.out.println("App Closed.....Bye");
					System.exit(0);
					
				}
				default:
					System.out.println("Invalid Option..");
					handleApp();
				}
			}catch(Exception ex) {
				ex.printStackTrace();
			}
		}while(showDetail == true);
		scan.close();
	}
	
	public static void showAllProduct() {
		List<Product> list = new ProductManagementDAO().listOfAllProduct();
		for(Product pro : list) {
			System.out.println("Product Id : "+pro.getPid());
			System.out.println("Product Name : "+pro.getPname());
			System.out.println("Product Price :Rs. "+pro.getPrice()+"\n");
		}
		System.out.print("\n\n");
	}
	
	public static void insertValueInDatabase() {
		ProductManagementDAO dao = new ProductManagementDAO();
		Product product = new Product();
		Scanner scan = new Scanner(System.in);
		
		System.out.println("----------------------\n"+"Enter Product ID :\n----------------------");
		int pid = Integer.parseInt(scan.nextLine());
		product.setPid(pid);
		
		System.out.println("-----------------------------\n"+"Enter Product Name :\n-----------------------------");
		String pname = scan.nextLine();
		product.setPname(pname);
		
		System.out.println("-----------------------------\n"+"Enter Product Price :\n-----------------------------");
		float price = Float.parseFloat(scan.nextLine());
		product.setPrice(price);
		
		dao.insertProduct(product);
		System.out.println("Product Added Successfully");
		
	}
	
	public static void deleteValueFromDatabase(int pid) {
		
		ProductManagementDAO dao = new ProductManagementDAO();
		dao.deleteProduct(pid);
		System.out.println("Product Deleted Successfully..\n\n");
	}
	
	public static void UpdateProductInDatabase() {
		Scanner scan = new Scanner(System.in);
		ProductManagementDAO dao = new ProductManagementDAO();
		
		
		System.out.println("----------------------\n"+"Enter Product ID :\n----------------------");
		int pid = Integer.parseInt(scan.nextLine());
		
		System.out.println("----------------------\n"+"Enter Product New Product Name:\n----------------------");
		String newProductName = scan.nextLine();
		
		System.out.println("----------------------\n"+"Enter Product New Prodct Price :\n----------------------");
		float newProductPrice = Float.parseFloat(scan.nextLine());
		
		dao.updateProduct(pid, newProductName, newProductPrice);
		System.out.println("Update Successfull..");
		
		scan.close();
	}
	
	public static void searchProduct(int pid) {
		
		ProductManagementDAO dao = new ProductManagementDAO();		
		Product product = dao.searchProduct(pid);
		
		System.out.println("Product Id : "+product.getPid());
		System.out.println("Product Name : "+product.getPname());
		System.out.println("Product Price :Rs. "+product.getPrice()+"\n");
	}

}
