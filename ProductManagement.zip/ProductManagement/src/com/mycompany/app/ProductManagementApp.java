package com.mycompany.app;


public class ProductManagementApp {

	public static void main(String[] args) {
		
		
		ProductManagementMenu.handleApp();

	}

}
