package com.mycompany.dao;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mycompany.domain.Product;
import com.mycompany.dbuilt.DBuilt;

public class ProductManagementDAO {

	public boolean insertProduct(Product product) {
		
		try {
			String sql = ("insert into product values (?,?,?)");
			PreparedStatement ps = DBuilt.getConnection().prepareStatement(sql);
			
			ps.setInt(1,product.getPid());
			ps.setString(2, product.getPname());
			ps.setFloat(3,product.getPrice());
			
			return ps.executeUpdate()>0;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean deleteProduct(int pid) {
		try {
			String sql = "delete from product where pid=?";
			PreparedStatement ps = DBuilt.getConnection().prepareStatement(sql);
			
			ps.setInt(1,pid);
			
			return ps.executeUpdate()>0;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean updateProduct(int pid, String pname, float price) {
		
		String sql = "update product set pname=?,price=? where pid = ?";
		try {
			PreparedStatement ps = DBuilt.getConnection().prepareStatement(sql);
			ps.setString(1,pname);
			ps.setFloat(2,price);
			ps.setInt(3, pid);
			
			return ps.executeUpdate()>0;
		} catch (Exception e) {
			// TODO: handle exception
		}
	return false;
	}
	
	public Product searchProduct(int pid) {

		try {
			String sql = "Select pid , pname, price from product where pid=?";
			PreparedStatement ps = DBuilt.getConnection().prepareStatement(sql);
			ps.setInt(1,pid);
			 
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()) {
				Product product = new Product();
				product.setPid(rs.getInt(1));
				product.setPname(rs.getString(2));
				product.setPrice(rs.getFloat(3));
				
				return product;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	public List<Product> listOfAllProduct(){
		List<Product> list = null;
		try {
			list = new ArrayList<Product>();
			String sql = "select pid,pname,price from product";
			PreparedStatement ps = DBuilt.getConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				Product product = new Product();
				product.setPid(rs.getInt(1));
				product.setPname(rs.getString(2));
				product.setPrice(rs.getFloat(3));
				
				list.add(product);
			}
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	}
	

