package com.pack;



public class split {

	public static void main(String[] args) {
	
		
		String str = "23  +      45   - (   343   /   12  )";
		
		String splitofstring[] = str.split(" ");
		
		for (String string : splitofstring) {
			System.out.println(string);
		}

	}

}
