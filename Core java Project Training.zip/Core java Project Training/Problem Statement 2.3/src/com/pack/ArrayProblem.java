package com.pack;

public class ArrayProblem {
	public static void main(String[] args) {
		int a[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
		int sum = 0;
		for(int i = 0 ; i< 14 ; i++) {
			sum = sum + a[i];
		}
		a[15] = sum ;
		System.out.println(a[15]);
		
		int add= 0;
		for(int i = 0; i<a.length ; i++) {
			 add = add + a[i];
			 
		}
		int average = add/a.length;
		a[16] = average;
		System.out.println(a[16]);
	}

}
