package com.pack;
import java.util.*;
public class FrequencySort {

	static HashMap<Integer, Integer> find(int []arr, int size){
	    
		  
		   HashMap<Integer,Integer> frequency = new HashMap<Integer,Integer>();
		    
		   
		   for(int i = 0; i < size; i++)
		   {
		       if(frequency.containsKey(arr[i]))
		       {
		           frequency.put(arr[i], frequency.get(arr[i]) + 1);
		       }
		       else
		       {
		           frequency.put(arr[i], 1);
		       }
		   }
		   return frequency;
		}

		public static void main(String []args)
		{
		    int []arr = {2, 2, 2, 4, 4, 4, 5, 5, 6, 8, 8, 9 };
		    
		    int arr_size = arr.length;
		    
		    HashMap<Integer,Integer> frequency = find(arr, arr_size);
		    
		    System.out.println("Below is the frequency"+"of repeated elements -");
		    
		    for (Map.Entry<Integer,Integer> entry : frequency.entrySet())
		        if (entry.getValue() > 1)
		            System.out.println(entry.getKey()+ " Occurs "+entry.getValue()+ " Times");
		}
}
