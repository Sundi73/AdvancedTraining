package com.pack2;

import com.pack.Book;

public class test {

	public static void main(String[] args) {
		Book b1= new Book();
		Book b2= new Book();
		
		b1.setBook_title("java programming");
		b1.setBook_price(350);
		
		b2.setBook_title("Let us C");
		b2.setBook_price(200);
		
		System.out.println("Book Title -------- Price");
		
		b1.showBook();
		b2.showBook();
		
	}
}
