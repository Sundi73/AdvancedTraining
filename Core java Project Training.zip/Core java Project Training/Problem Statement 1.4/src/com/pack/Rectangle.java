package com.pack;

public class Rectangle {
	
	private double length;
	private double breath;
	
	public Rectangle() {
		length = 1;
		breath = 1;
	}
	
	public double perimeter() {
		return 2*(length+breath);
	}
	
	public double area() {
		return length*breath;
	}
	
	public void setValue(double length, double breath) {
		if(length > 0 && length < 20)
			this.length = length ;
		if(breath > 0 && breath < 20) {
			this.breath = breath ;
		}
	}
	
	public double getBreath() {
		return breath;
	}
	
	public double getLength() {
		return length;
	}
	
	

}

class test{
	
	
	public static void main(String[] args) {
		Rectangle r1 = new Rectangle();
		r1.setValue(10.0, 5.0);
		
		System.out.println("Length : "+ r1.getLength());
		System.out.println("Breath : "+ r1.getBreath());
		System.out.println("Perimeter : "+ r1.perimeter());
		System.out.println("Breath : "+ r1.area());
		
		
	}
	
	
	
	
	
	
}
